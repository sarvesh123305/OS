make
./bc
